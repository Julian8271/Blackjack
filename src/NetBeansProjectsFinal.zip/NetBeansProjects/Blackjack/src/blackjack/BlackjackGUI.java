package blackjack;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class BlackjackGUI extends JFrame {

    // --- Variables de la lógica del juego ---
    private Juego juego;
    private List<Jugador> jugadores;
    private int turnoActual = 0;
    private Carta cartaOcultaCrupier;

    // --- Componentes de la Interfaz Gráfica (GUI) ---
    // Paneles principales que organizan las áreas de la ventana
    private JPanel panelCartasJugador;
    private JPanel panelCartasCrupier;

    // Etiquetas para mostrar información clave
    private JLabel lblTurno;
    private JLabel iblTurnoCrupier; // Cambiado para mostrar info del crupier
    private JLabel lblPuntaje;
    private JLabel lblFichas;
    private JLabel lblCartaOculta;

    // Botones de acción del jugador
    private JButton btnDividir;
    private JButton btnDoblar;
    private JButton btnRendirse;

    /**
     * Constructor principal de la ventana del juego.
     */
    public BlackjackGUI() {
        setTitle("Blackjack Multijugador");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Usamos BorderLayout como el gestor principal de la ventana.
        // Esto nos permite dividirla en secciones: NORTH, SOUTH, CENTER, EAST, WEST.
        setLayout(new BorderLayout(10, 10)); // Añadimos espacio entre las secciones

        juego = new Juego();
        jugadores = new ArrayList<>();

        // --- Configuración Inicial de Jugadores ---
        int numJugadores = pedirNumero("¿Cuántos jugadores?", 1, 4);
        for (int i = 1; i <= numJugadores; i++) {
            String nombre = JOptionPane.showInputDialog("Nombre del jugador " + i + ":");
            while (nombre == null || nombre.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nombre Invalido.");
                nombre = JOptionPane.showInputDialog("Nombre del jugador " + i + ":");
            }
            juego.agregarJugador(nombre);
        }

        jugadores = juego.getJugadores();
        iniciarRonda(); // Llama al método que construye la interfaz de la ronda
    }

    public void iniciarRonda() {
        getContentPane().removeAll(); // Limpiamos la ventana antes de empezar una nueva ronda

        // --- 1. Panel de Información (ARRIBA - NORTH) ---
        // Usamos un GridLayout de 2x2 para organizar las 4 etiquetas de forma ordenada.
        JPanel panelInfo = new JPanel(new GridLayout(2, 2, 10, 5));
        lblTurno = new JLabel("Turno de:", SwingConstants.CENTER);
        lblTurno.setFont(new Font("Arial", Font.BOLD, 20));
        iblTurnoCrupier = new JLabel("Crupier:", SwingConstants.CENTER);
        iblTurnoCrupier.setFont(new Font("Arial", Font.BOLD, 20));
        lblPuntaje = new JLabel("Puntaje: 0", SwingConstants.CENTER);
        lblFichas = new JLabel("Fichas: 0", SwingConstants.CENTER);

        panelInfo.add(lblTurno);
        panelInfo.add(iblTurnoCrupier);
        panelInfo.add(lblPuntaje);
        panelInfo.add(lblFichas);
        add(panelInfo, BorderLayout.NORTH); // Añadimos el panel de info a la parte de arriba

        // --- 2. Panel Central para las Cartas (EN EL MEDIO - CENTER) ---
        // Este panel usará GridLayout para dividirse en dos filas: una para el crupier y otra para el jugador.
        JPanel panelDeMesas = new JPanel(new GridLayout(2, 1, 0, 10)); // 2 filas, 1 columna

        // Panel del Crupier: Usamos FlowLayout.CENTER para que las cartas se centren horizontalmente.
        panelCartasCrupier = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelCartasCrupier.setBorder(BorderFactory.createTitledBorder("Mano del Crupier")); // Un borde para que se vea mejor

        // Panel del Jugador: También centrado.
        panelCartasJugador = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelCartasJugador.setBorder(BorderFactory.createTitledBorder("Tu Mano"));

        panelDeMesas.add(panelCartasCrupier); // El crupier va en la fila de arriba
        panelDeMesas.add(panelCartasJugador); // El jugador va en la fila de abajo
        add(panelDeMesas, BorderLayout.CENTER); // Añadimos el panel de mesas a la zona central

        // --- 3. Panel de Botones (ABAJO - SOUTH) ---
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER)); // Centramos los botones
        JButton btnPedir = new JButton("Pedir Carta");
        JButton btnPlantarse = new JButton("Plantarse");
        btnDoblar = new JButton("Doblar Apuesta");
        btnDividir = new JButton("Dividir");
        btnRendirse = new JButton("Rendirse");

        panelBotones.add(btnPedir);
        panelBotones.add(btnPlantarse);
        panelBotones.add(btnDoblar);
        panelBotones.add(btnDividir);
        panelBotones.add(btnRendirse);
        add(panelBotones, BorderLayout.SOUTH); // Añadimos los botones a la parte de abajo

        // --- Lógica de los Eventos (Listeners) ---
        // Acción: Pedir carta
        btnPedir.addActionListener(e -> {
            Jugador jugador = jugadores.get(turnoActual);
            Carta carta = juego.getMazo().sacarCarta();
            jugador.recibirCarta(carta);
            mostrarManoJugador(jugador);
            actualizarInfoJugador(jugador);

            if (jugador.volo()) {
                JOptionPane.showMessageDialog(this, jugador.getNombre() + " se pasó de 21.");
                siguienteTurno();
            }
        });

        // Acción: Plantarse
        btnPlantarse.addActionListener(e -> siguienteTurno());

        // Acción: Doblar
        btnDoblar.addActionListener(e -> {
            Jugador jugador = jugadores.get(turnoActual);

            // Validación reforzada
            if (jugador.getMano().size() == 2 && !jugador.haDividido()
                    && jugador.getFichas() >= jugador.getApuestaActual()) {

                if (jugador.doblarApuesta()) {
                    Carta carta = juego.getMazo().sacarCarta();
                    jugador.recibirCarta(carta);
                    mostrarManoJugador(jugador);
                    actualizarInfoJugador(jugador);

                    if (jugador.volo()) {
                        JOptionPane.showMessageDialog(this, jugador.getNombre() + " se pasó de 21.");
                    }
                    siguienteTurno();
                } else {
                    JOptionPane.showMessageDialog(this, "No puedes doblar la apuesta.");
                }
            } else {
                JOptionPane.showMessageDialog(this,
                        "Solo puedes doblar:\n- Con exactamente 2 cartas\n- Antes de dividir\n- Con fichas suficientes",
                        "No se puede doblar", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Acción: Dividir
        btnDividir.addActionListener(e -> {
            Jugador jugador = jugadores.get(turnoActual);
            if (jugador.puedeDividir()) {
                int confirmacion = JOptionPane.showConfirmDialog(this,
                        "¿Dividir mano? Esto duplicará tu apuesta", "Confirmar Split", JOptionPane.YES_NO_OPTION);
                if (confirmacion == JOptionPane.YES_OPTION) {
                    jugador.dividir();
                    mostrarManoJugador(jugador);
                    actualizarInfoJugador(jugador);
                    JOptionPane.showMessageDialog(this, "Mano dividida. Jugarás primero tu mano principal.");
                }
            } else {
                JOptionPane.showMessageDialog(this,
                        "No puedes dividir. Necesitas:\n- Dos cartas del mismo valor\n- Fichas suficientes",
                        "No se puede dividir", JOptionPane.WARNING_MESSAGE);
            }
        });

// ActionListener para el botón de rendirse
        btnRendirse.addActionListener(e -> {
            Jugador jugador = jugadores.get(turnoActual);

            if (jugador.rendirse2()) {
                JOptionPane.showMessageDialog(this,
                        jugador.getNombre() + " se ha rendido. Recuperó " + (jugador.getApuestaActual() / 2) + " fichas.",
                        "Rendición",
                        JOptionPane.INFORMATION_MESSAGE);
                siguienteTurno();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Solo puedes rendirte:\n- En tu primer turno\n- Con exactamente 2 cartas\n- Antes de dividir o doblar",
                        "No puedes rendirte ahora",
                        JOptionPane.WARNING_MESSAGE);
            }
        });

        // Preparamos el juego y a los jugadores para la ronda
        prepararJugadores();

        // Refrescamos la ventana para que muestre todos los componentes nuevos
        revalidate();
        repaint();
    }

    /**
     * Prepara a los jugadores y al crupier para el inicio de la ronda. Pide
     * apuestas y reparte las cartas iniciales.
     */
    private void prepararJugadores() {
        juego.getMazo().barajar();

        // Cada jugador hace su apuesta
        for (Jugador j : jugadores) {
            while (true) {
                try {
                    String apuestaStr = JOptionPane.showInputDialog(this, j.getNombre() + ", ¿cuántas fichas apuestas? (Tienes: " + j.getFichas() + ")");
                    if (apuestaStr == null) {
                        System.exit(0);
                    }
                    int apuesta = Integer.parseInt(apuestaStr);
                    j.apostar(apuesta);
                    break;
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Número inválido.");
                }
            }
            j.limpiarMano();
            j.recibirCarta(juego.getMazo().sacarCarta());
            j.recibirCarta(juego.getMazo().sacarCarta());
        }

        // El crupier recibe sus cartas
        Crupier crupier = juego.getCrupier();
        crupier.limpiarMano();
        crupier.recibirCarta(juego.getMazo().sacarCarta());
        cartaOcultaCrupier = juego.getMazo().sacarCarta();
        crupier.recibirCarta(cartaOcultaCrupier);

        // Lógica de seguro si el crupier muestra un As
        if (crupier.getMano().get(0).getValor().equals("As")) {
            for (Jugador jugador : jugadores) {
                int respuesta = JOptionPane.showConfirmDialog(this,
                        jugador.getNombre() + ", el crupier muestra un As. ¿Quieres seguro?",
                        "Seguro", JOptionPane.YES_NO_OPTION);
                if (respuesta == JOptionPane.YES_OPTION) {
                    jugador.apostarSeguro(jugador.getApuestaActual() / 2);
                }
            }
        }

        mostrarTurno(); // Muestra el primer turno
    }

    /**
     * Actualiza la interfaz para reflejar el turno del jugador actual.
     */
    private void mostrarTurno() {
        if (turnoActual >= jugadores.size()) {
            turnoCrupier();
            return;
        }

        Jugador jugador = jugadores.get(turnoActual);
        lblTurno.setText("Turno de: " + jugador.getNombre());
        actualizarInfoJugador(jugador);

        // Muestra la mano del jugador actual
        mostrarManoJugador(jugador);

        // Muestra la mano del crupier (con una carta oculta)
        panelCartasCrupier.removeAll();
        Crupier crupier = juego.getCrupier();
        mostrarCarta(panelCartasCrupier, crupier.getMano().get(0)); // Carta visible

        // Añadimos la imagen del dorso de la carta
        ImageIcon dorsoIcon = new ImageIcon(getClass().getResource("/resources/cartas/dorso.png"));
        Image dorsoImagen = dorsoIcon.getImage().getScaledInstance(100, 150, Image.SCALE_SMOOTH);
        lblCartaOculta = new JLabel(new ImageIcon(dorsoImagen));
        panelCartasCrupier.add(lblCartaOculta);

        // Actualizamos los botones
        btnDividir.setEnabled(jugador.puedeDividir());
        btnDoblar.setEnabled(jugador.getMano().size() == 2 && jugador.getFichas() >= jugador.getApuestaActual());
        btnDoblar.setEnabled(
                jugador.getMano().size() == 2
                && !jugador.haDividido()
                && jugador.getFichas() >= jugador.getApuestaActual()
        );
        btnRendirse.setEnabled(
                jugador.getMano().size() == 2
                && !jugador.haDividido()
                && !jugador.haDoblado()
        );
        // Repintamos los paneles para que los cambios sean visibles
        panelCartasCrupier.revalidate();
        panelCartasCrupier.repaint();

    }

    /**
     * Actualiza las etiquetas de puntaje y fichas del jugador.
     */
    private void actualizarInfoJugador(Jugador j) {
        lblPuntaje.setText("Puntaje: " + j.getPuntaje()
                + (j.getSegundaMano().isEmpty() ? "" : " | Split: " + j.getPuntajeSegundaMano()));
        lblFichas.setText("Fichas: " + j.getFichas() + (j.getSeguro() > 0 ? " | Seguro: " + j.getSeguro() : ""));
    }

    /**
     * Dibuja todas las cartas de un jugador en su panel correspondiente. Esto
     * incluye la mano principal y la segunda mano si la hubiera (split).
     */
    private void mostrarManoJugador(Jugador j) {
        panelCartasJugador.removeAll();

        // Panel para la mano principal
        JPanel panelMano1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        panelMano1.setBorder(BorderFactory.createTitledBorder("Mano Principal"));
        for (Carta c : j.getMano()) {
            mostrarCarta(panelMano1, c);
        }
        panelCartasJugador.add(panelMano1);

        // Panel para la segunda mano si existe
        if (!j.getSegundaMano().isEmpty()) {
            JPanel panelSplit = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
            panelSplit.setBorder(BorderFactory.createTitledBorder("Mano Dividida"));
            for (Carta c : j.getSegundaMano()) {
                mostrarCarta(panelSplit, c);
            }
            panelCartasJugador.add(panelSplit);
        }

        panelCartasJugador.revalidate();
        panelCartasJugador.repaint();
    }

    private void mostrarCarta(JPanel panel, Carta carta) {
        String nombreImagen = carta.getValor().trim() + "_de_" + carta.getPalo().trim() + ".png";
        try {
            ImageIcon icono = new ImageIcon(getClass().getResource("/resources/cartas/" + nombreImagen));
            Image imagen = icono.getImage().getScaledInstance(100, 150, Image.SCALE_SMOOTH);
            JLabel labelCarta = new JLabel(new ImageIcon(imagen));
            panel.add(labelCarta);
        } catch (Exception e) {
            System.err.println("⚠️ No se encontró la imagen: " + nombreImagen);
            // Si la imagen no se encuentra, muestra un texto en su lugar
            panel.add(new JLabel(carta.getValor() + " " + carta.getPalo()));
        }
    }

    /**
     * Pasa al siguiente jugador o inicia el turno del crupier.
     */
    private void siguienteTurno() {
        turnoActual++;
        if (turnoActual >= jugadores.size()) {
            turnoCrupier();
        } else {
            mostrarTurno();
        }
    }

    /**
     * Inicia la lógica y animación del turno del crupier.
     */
    private void turnoCrupier() {
        lblTurno.setText("Turno del Crupier");
        Crupier crupier = juego.getCrupier();

        // Volteamos la carta oculta
        panelCartasCrupier.removeAll();
        for (Carta c : crupier.getMano()) {
            mostrarCarta(panelCartasCrupier, c);
        }
        panelCartasCrupier.revalidate();
        panelCartasCrupier.repaint();

        // Usamos un Timer para que el crupier pida cartas con una pausa, haciendo el juego más visual.
        Timer timer = new Timer(1000, e -> {
            if (crupier.getPuntaje() < 17) {
                Carta nueva = juego.getMazo().sacarCarta();
                crupier.recibirCarta(nueva);
                mostrarCarta(panelCartasCrupier, nueva);
                panelCartasCrupier.revalidate();
                panelCartasCrupier.repaint();
            } else {
                ((Timer) e.getSource()).stop(); // Detenemos el timer
                evaluarResultados(); // Una vez que el crupier termina, evaluamos los resultados
            }
        });
        timer.start();
    }

    /**
     * Compara las manos de los jugadores con la del crupier y muestra los
     * resultados.
     */
    /**
     * Compara las manos de los jugadores con la del crupier y muestra los
     * resultados.
     */
    private void evaluarResultados() {
        Crupier crupier = juego.getCrupier();
        StringBuilder resumen = new StringBuilder("--- Resultados Finales ---\n");
        resumen.append("Crupier tiene: ").append(crupier.getPuntaje()).append("\n\n");

        for (Jugador j : jugadores) {
            // Lógica de evaluación para cada jugador...
            // (Esta parte de tu código ya estaba bien)
            if (j.volo()) {
                resumen.append(j.getNombre()).append(" pierde (se pasó de 21).\n");
                j.perderApuesta();
            } else if (crupier.volo() || j.getPuntaje() > crupier.getPuntaje()) {
                resumen.append(j.getNombre()).append(" GANA con ").append(j.getPuntaje()).append("!\n");
                j.ganarApuesta();
            } else if (j.getPuntaje() == crupier.getPuntaje()) {
                resumen.append(j.getNombre()).append(" empata con ").append(j.getPuntaje()).append(".\n");
                j.empateApuesta();
            } else {
                resumen.append(j.getNombre()).append(" pierde con ").append(j.getPuntaje()).append(".\n");
                j.perderApuesta();
            }
        }

        JOptionPane.showMessageDialog(this, resumen.toString());
        preguntarOtraRonda();
    }

    /**
     * Pregunta si se desea jugar otra ronda y elimina a los jugadores sin
     * fichas.
     */
    private void preguntarOtraRonda() {
        // --- LÓGICA DE ELIMINACIÓN DE JUGADORES ---
        // 1. Creamos una lista para guardar a los jugadores que vamos a eliminar.
        List<Jugador> jugadoresAEliminar = new ArrayList<>();
        StringBuilder mensajeEliminacion = new StringBuilder();

        // 2. Recorremos la lista de jugadores para ver quién se quedó sin fichas.
        for (Jugador j : jugadores) {
            if (j.getFichas() <= 0) {
                jugadoresAEliminar.add(j);
                mensajeEliminacion.append(j.getNombre()).append(" ha sido eliminado por quedarse sin fichas.\n");
            }
        }

        // 3. Si hay jugadores en la lista de eliminación, los quitamos del juego.
        if (!jugadoresAEliminar.isEmpty()) {
            JOptionPane.showMessageDialog(this, mensajeEliminacion.toString(), "Jugadores Eliminados", JOptionPane.WARNING_MESSAGE);
            jugadores.removeAll(jugadoresAEliminar);
        }

        // 4. Verificamos si aún quedan jugadores en la partida.
        if (jugadores.isEmpty()) {
            JOptionPane.showMessageDialog(this, "¡Todos los jugadores han sido eliminados! Gracias por jugar.");
            System.exit(0);
            return; // Salimos del método
        }

        // --- LÓGICA ORIGINAL PARA CONTINUAR JUGANDO ---
        int respuesta = JOptionPane.showConfirmDialog(this, "¿Quieren jugar otra ronda?", "Continuar", JOptionPane.YES_NO_OPTION);
        if (respuesta == JOptionPane.YES_OPTION) {
            turnoActual = 0; // Reiniciamos el turno al primer jugador de la lista actualizada
            iniciarRonda();
        } else {
            JOptionPane.showMessageDialog(this, "¡Gracias por jugar!");
            System.exit(0);
        }
    }

    private int pedirNumero(String mensaje, int minimo, int maximo) {
        while (true) {
            try {
                String entrada = JOptionPane.showInputDialog(this, mensaje + " (" + minimo + " - " + maximo + ")");
                if (entrada == null) {
                    System.exit(0);
                }
                int numero = Integer.parseInt(entrada);
                if (numero >= minimo && numero <= maximo) {
                    return numero;
                } else {
                    JOptionPane.showMessageDialog(this, "Por favor ingresa un número entre " + minimo + " y " + maximo);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Eso no es un número válido.");
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     *//*
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 127, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 66, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 273, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 234, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
/*
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // Se recomienda usar SwingUtilities.invokeLater para asegurar que la GUI se cree
        // en el hilo de despacho de eventos (Event Dispatch Thread).
        SwingUtilities.invokeLater(() -> {
            new BlackjackGUI().setVisible(true);
        });
    }
    /*java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BlackjackGUI().setVisible(true);
            }
        });*/
 /*

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
*/

}
