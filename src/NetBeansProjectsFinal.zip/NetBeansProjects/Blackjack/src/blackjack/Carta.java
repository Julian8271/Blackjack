/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package blackjack;


public class Carta {
    // Atributos de una carta individual
    private String palo;  // Ej: "Corazones", "Picas", etc.
    private String valor; // Ej: "As", "2", ..., "K"

    // Constructor de una carta 
    public Carta(String palo, String valor) {
        this.palo = palo;
        this.valor = valor;
    }


    public int getValorNumerico() {
        if (valor.equals("As")) {
            return 11; // El As vale 11 por defecto, pero en caso de que el puntaje se pase este tomara un valor de 1
        } else if (valor.equalsIgnoreCase("J") || valor.equalsIgnoreCase("Q") || valor.equalsIgnoreCase("K")) {
            return 10;
        } else {
            // Convierte el valor (String) a número (ej: "7" → 7) mediante un casteo 
            return Integer.parseInt(valor);
        }
    }
    @Override
    public String toString() {
        //Sobreecribimos el metodo toString para que nos muestre las cartas con sus simbolos 
        //Los simbolos estaran guardados en una variable aparte 
        String simboloPalo = " ";
        switch (palo) {
            case "Corazones": simboloPalo = " Corazones "; break;
            case "Diamantes": simboloPalo =" Diamantes "; break;
            case "Picas": simboloPalo = " Picas "; break;
            case "Treboles": simboloPalo = " Treboles "; break;
        }
        //Se retorna la concatenacion para que la salida visual sea la esperada
        return valor + simboloPalo;
    }
    //Metodo para obtener el valor de la carta 
    public String getValor(){
        return valor;
    }
    public String getPalo(){
        return palo;
    }
}